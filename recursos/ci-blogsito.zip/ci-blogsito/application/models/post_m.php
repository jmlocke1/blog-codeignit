<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Post_m extends MY_Model {

  protected $_table_name = 'posts';

  public $rules = array(
    'title' => array(
      'field' => 'title',
      'label' => 'Titulo',
      'rules' => 'trim|required'
    ),
    'body' => array(
      'field' => 'body',
      'label' => 'Descripcion',
      'rules' => 'trim|required'
    ),
    'category_id' => array(
      'field' => 'category_id',
      'label' => 'Categoria',
      'rules' => 'trim|required'
    )
  );

  public function get_new()
  {
    $post = new stdClass(); //clase vacia
    $post->image = '';
    $post->title = '';
    $post->body = '';
    $post->category_id = 0;

    return $post;
  }

  public function get_posts($category_id = NULL)
  {
    if ($category_id != NULL) 
      $this->db->where('category_id', $category_id);
      
    $this->db->select('c.name, p.*');
    $this->db->from('posts p');
    $this->db->join('categories c', 'c.id = p.category_id', 'left');
    $this->db->order_by('p.created_at', 'desc');

    return $this->db->get()->result();
  }
}

/* End of file post_m.php */
/* Location: ./application/models/post_m.php */