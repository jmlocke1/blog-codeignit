<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Category_m extends MY_Model {

  protected $_table_name = 'categories';

  public $rules = array(
    'category' => array(
      'field' => 'name',
      'label' => 'Categoria',
      'rules' => 'trim|required'
    )
  );

  public function get_new()
  {
    $category = new stdClass(); //clase vacia
    $category->name = '';

    return $category;
  }

  public function get_categories()
  {
    $this->db->select('c.id, c.name, count(*) as num_posts');
    $this->db->from('posts p');
    $this->db->join('categories c', 'c.id = p.category_id', 'left');
    $this->db->group_by('name');

    return $this->db->get()->result();
  }

}

/* End of file post_m.php */
/* Location: ./application/models/post_m.php */