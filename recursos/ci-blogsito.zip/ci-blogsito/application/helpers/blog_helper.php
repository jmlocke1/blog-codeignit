<?php 

function format_date($date)
{
  setlocale(LC_TIME, "spanish");
  return strftime('%d %B, %Y', strtotime($date)); 
}

function limit_numwords($string, $numwords)
{
  $excerpt = explode(' ', $string, $numwords + 1);

  if (count($excerpt) >= $numwords) {
    array_pop($excerpt);
  }

  $excerpt = implode(' ', $excerpt);

  return $excerpt;
}