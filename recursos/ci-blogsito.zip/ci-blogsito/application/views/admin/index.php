<div class="card shadow mb-4">
  <div class="card-header py-3">
    <h6 class="m-0 font-weight-bold text-primary">Bienvenido <?php echo $this->session->userdata('name'); ?>!</h6>
  </div>
  <div class="card-body">
    <p>Puedes acceder a los enlaces para ver, editar o eliminar tus articulos</p>
    <a href="<?php echo site_url('admin/category'); ?>">Ver categorias &rarr;</a>
    <br>
    <a href="<?php echo site_url('admin/post'); ?>">Ver articulos &rarr;</a>
  </div>
</div>