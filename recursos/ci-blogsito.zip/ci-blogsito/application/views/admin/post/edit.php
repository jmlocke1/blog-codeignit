<div class="card shadow mb-4">
  <div class="card-header py-3"><?php echo empty($post->title) ? 'Nuevo Articulo' : 'Editar articulo'; ?> </div>
  <div class="card-body">
    <?php if(validation_errors()) { ?>
      <div class="alert alert-danger alert-dismissible fade show" role="alert">
        <?php echo validation_errors('<li>', '</li>'); ?>
        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
    <?php } ?>
    <?php if ($this->session->flashdata('error_msg')): ?>
      <div class="alert alert-danger alert-dismissible fade show" role="alert">
        <?= $this->session->flashdata('error_msg') ?>
        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
    <?php endif ?>
    <!-- <?php if (!empty($error_msg)): ?>
      <div class="alert alert-danger alert-dismissible fade show" role="alert">
        <?= $error_msg ?>
        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
    <?php endif ?> -->
    <?php echo form_open_multipart(); ?>
      <div class="form-group">
        <label class="small mb-1" for="inputUsername">Subir Imagen</label>

        <?php if ($post->image == ''): ?>
          <img src="<?php echo site_url('assets/images/default.jpg'); ?>" id="img_url" alt="tu imagen" class="img-thumbnail">
        <?php else: ?>
          <img src="<?php echo site_url('assets/images/'.$post->image); ?>" id="img_url" alt="tu imagen" class="img-thumbnail">
        <?php endif; ?>

        <input type="hidden" name="image_name" value="<?php echo $post->image ?>">
        <input class="form-control-file mt-2" id="inputUsername" type="file" name="image" onChange="img_pathUrl(this);">
      </div>
      <div class="form-group">
        <label class="small mb-1" for="inputUsername">Ingresar Titulo</label>
        <input class="form-control" id="inputUsername" type="text" name="title" value="<?php echo set_value('name', $this->input->post('title') ? $this->input->post('title') : $post->title); ?>">
      </div>
      <div class="form-group">
        <label class="small mb-1" for="exampleFormControlTextarea1">Ingresar Descripción</label>
        <textarea class="form-control" id="exampleFormControlTextarea1" rows="3" name="body"><?php echo set_value('body', $post->body); ?></textarea>
      </div>
      <div class="form-group">
        <label class="small mb-1" for="exampleFormControlSelect2">Seleccionar Categoria</label>
        <select class="form-control" id="exampleFormControlSelect2" name="category_id">
          <?php if ($post->category_id == 0): ?>
            <option value = "" selected>Seleccionar categoria</option>
          <?php endif ?>
          <?php foreach ($categories as $category): ?>
            <option value="<?php echo $category->id ?>" <?php if ($category->id == $post->category_id) echo "selected" ?> <?php echo set_select('category_id', $category->id) ?>><?php echo $category->name ?></option>
          <?php endforeach ?>
          
        </select>
      </div>
      <button class="btn btn-primary" type="submit">Registrar Articulo</button>
    <?php echo form_close() ?>
  </div>
</div>