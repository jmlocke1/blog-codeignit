<div class="card shadow mb-4">
  <div class="card-header py-3"><?php echo empty($category->name) ? 'Nueva Categoria' : 'Editar categoria'; ?> </div>
  <div class="card-body">
    <?php if(validation_errors()) { ?>
      <div class="alert alert-danger alert-dismissible fade show" role="alert">
        <?php echo validation_errors('<li>', '</li>'); ?>
        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
    <?php } ?>
    <?php echo form_open() ?>
      <div class="form-group">
        <label class="small mb-1" for="inputUsername">Ingresar Categoria</label>
        <input class="form-control" id="inputUsername" name="name" type="text" value="<?php echo set_value('name', $category->name); ?>">
      </div>
      <button class="btn btn-primary" type="submit">Registrar Categoria</button>
    <?php echo form_close() ?>
  </div>
</div>