<div class="row pt-md-4">
  <p>
    <img src="<?php echo site_url('/assets/images/'.$post->image); ?>" alt="" class="img-fluid">
  </p>
  <h1 class="mb-3"><?php echo $post->title ?></h1>
  <p><?php echo $post->body ?></p>
</div><!-- END-->