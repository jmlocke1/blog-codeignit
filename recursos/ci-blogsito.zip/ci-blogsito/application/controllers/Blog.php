<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Blog extends CI_Controller {

  public function __construct()
  {
    parent::__construct();
    $this->load->model('post_m');
    $this->load->model('category_m');
    $this->load->helper('blog');
  }

  public function index()
  {
    $data['posts'] = $this->post_m->get_posts();
    //echo $this->db->last_query();
    $data['categories'] = $this->category_m->get_categories();
    $data['subview'] = 'index';
    $this->load->view('_blog_layout', $data);
  }

  public function post($post_id)
  {
    $data['categories'] = $this->category_m->get_categories();
    $data['post'] = $this->post_m->get($post_id);
    $data['subview'] = 'post';
    $this->load->view('_blog_layout', $data);
  }

  public function category($category_id)
  {
    $data['posts'] = $this->post_m->get_posts($category_id);
    $data['categories'] = $this->category_m->get_categories();
    $data['subview'] = 'category';
    $this->load->view('_blog_layout', $data);
  }

  public function about()
  {
    $data['subview'] = 'about';
    $this->load->view('_pages_layout', $data);
  }

  public function contact()
  {
    $data['subview'] = 'contact';
    $this->load->view('_pages_layout', $data);
  }
}

/* End of file Blog.php */
/* Location: ./application/controllers/Blog.php */