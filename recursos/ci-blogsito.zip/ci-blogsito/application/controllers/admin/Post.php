<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Post extends CI_Controller {

  public function __construct()
  {
    parent::__construct();
    $this->load->model('post_m');
    $this->load->model('category_m');
    $this->load->library('form_validation');
    $this->load->library('session');
    $this->load->helper('blog');
    $this->session->userdata('loggedin') == TRUE || redirect('user/login');
  }

  public function index()
  {
    $data['posts'] = $this->post_m->get();
    $data['subview'] = 'admin/post/index';
    $this->load->view('admin/_main_layout', $data);
  }

  public function edit($id = NULL)
  {
    if ($id) {
      $data['post'] = $this->post_m->get($id);
    } else {
      $data['post'] = $this->post_m->get_new();
    }

    $data['categories'] = $this->category_m->get();

    $rules = $this->post_m->rules;
    $this->form_validation->set_rules($rules);

    if ($this->form_validation->run() == TRUE) {

      $post_data = $this->post_m->array_from_post(['category_id','title', 'body']);
      $post_data['author'] = $this->session->userdata('name');

      $config['upload_path']   = 'assets/images/';
      $config['allowed_types'] = 'jpg|png|jpeg';
      $config['overwrite']     = TRUE;
      $config['max_size']      = 1024;

      $this->load->library('upload', $config);

      if ($id) {

        if(!empty($_FILES['image']['name'])){
          if($this->upload->do_upload('image')){
            $file_data = $this->upload->data();
            $file_name = $file_data['file_name'];
            unlink('assets/images/'.$this->input->post('image_name'));

          }else{
            $this->session->set_flashdata('error_msg', $this->upload->display_errors());
            redirect(current_url());
          }
        }else{

          $file_name = $this->input->post('image_name');
        }

        $post_data['image'] = $file_name;
        $this->post_m->save($post_data, $id);

        $this->session->set_flashdata('msg', 'Articulo editado correctamente');

        redirect('admin/post');
      } 

      else {

        if($this->upload->do_upload('image')){

          $file_data = $this->upload->data();
          $file_name = $file_data['file_name'];

          $post_data['image'] = $file_name;
          $this->post_m->save($post_data);

          $this->session->set_flashdata('msg', 'Articulo agregado correctamente');

          redirect('admin/post');

        }else{
          $this->session->set_flashdata('error_msg', $this->upload->display_errors());
          //return;
        }

      }

    }

    $data['subview'] = 'admin/post/edit';
    $this->load->view('admin/_main_layout', $data);
  }

  public function delete($id)
  {
    $post = $this->post_m->get($id);
    $this->post_m->delete($id);
    unlink('assets/images/'.$post->image);
    $this->session->set_flashdata('msg', 'Articulo eliminado correctamente');
    redirect('admin/post');  
  }

  // public function _file_check()
  // {
  //   if(isset($_FILES['image']) && !empty($_FILES['image']['name'])){
  //     return true;
  //   }else{
  //     $this->form_validation->set_message('_file_check', 'Por favor elige un archivo para subir.');
  //     return false;
  //   }
  // }

}

/* End of file Post.php */
/* Location: ./application/controllers/admin/Post.php */