<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Category extends CI_Controller {

  public function __construct()
  {
    parent::__construct();
    $this->load->model('category_m');
    $this->load->library('form_validation');
    $this->load->library('session');
    $this->session->userdata('loggedin') == TRUE || redirect('user/login');
  }

  public function index()
  {
    $data['categories'] = $this->category_m->get();
    $data['subview'] = 'admin/category/index';
    $this->load->view('admin/_main_layout', $data);
  }

  public function edit($id = NULL)
  {
    if ($id) {
      $data['category'] = $this->category_m->get($id);
      //count((array)$data['category']) || $this->session->set_flashdata('msg', 'No existe esa categoria');
    } else {
      $data['category'] = $this->category_m->get_new();
    }

    $rules = $this->category_m->rules;
    $this->form_validation->set_rules($rules);

    if ($this->form_validation->run() == TRUE) {
      $data = $this->category_m->array_from_post(['name']);
      $this->category_m->save($data, $id);

      if ($id) {
        $this->session->set_flashdata('msg', 'Categoria editada correctamente');
      } else {
        $this->session->set_flashdata('msg', 'Categoria agregada correctamente');
      }
      
      redirect('admin/category');
    }

    $data['subview'] = 'admin/category/edit';
    $this->load->view('admin/_main_layout', $data);
  }

}

/* End of file Category.php */
/* Location: ./application/controllers/admin/Category.php */